<?php
declare(strict_types=1);

// Class harus dimuat SEBELUM session_start() agar object di session bisa di-unserialize.
require_once __DIR__ . '/src/bootstrap.php';

session_start();

/* ---------- Inisialisasi repository & token CSRF ---------- */

$repo = $_SESSION['repository'] ?? null;
if (!$repo instanceof StudentRepository) {
    $repo = new StudentRepository();
    $repo->create(new RegularStudent('M001', 'Alya', 'Informatika', 5000000));
    $repo->create(new ScholarshipStudent('M002', 'Bima', 'Sistem Informasi', 5000000, 40));
    $_SESSION['repository'] = $repo;
}
$_SESSION['csrf'] ??= bin2hex(random_bytes(24));

/* ---------- Penanganan aksi form (POST) ---------- */

/** Menjalankan aksi CRUD dan mengembalikan pesan sukses. */
function handlePost(StudentRepository $repo, array $post): string
{
    if (!hash_equals((string) $_SESSION['csrf'], (string) ($post['csrf'] ?? ''))) {
        throw new RuntimeException('Token keamanan tidak valid.');
    }

    switch ((string) ($post['action'] ?? '')) {
        case 'create':
            $repo->create(StudentFactory::fromInput($post));
            return 'Mahasiswa berhasil ditambahkan.';
        case 'update':
            $repo->update((string) ($post['old_id'] ?? ''), StudentFactory::fromInput($post));
            return 'Mahasiswa berhasil diperbarui.';
        case 'delete':
            $repo->delete((string) ($post['id'] ?? ''));
            return 'Mahasiswa berhasil dihapus.';
        default:
            throw new InvalidArgumentException('Aksi tidak valid.');
    }
}

$error  = '';
$notice = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $notice = handlePost($repo, $_POST);
        $_SESSION['repository'] = $repo;
    } catch (Throwable $ex) {
        $error = $ex->getMessage();
    }
}

/* ---------- Data untuk tampilan ---------- */

$edit   = isset($_GET['edit']) ? $repo->find((string) $_GET['edit']) : null;
$search = trim((string) ($_GET['q'] ?? ''));

$students = array_values(array_filter(
    $repo->all(),
    fn (Student $s): bool => $search === ''
        || stripos($s->getId() . ' ' . $s->getName() . ' ' . $s->getMajor(), $search) !== false
));

// Demo overloading lewat __call(): 3 argumen valid, 1 argumen ditolak.
$presenter   = new StudentPresenter();
$demoValid   = $presenter->showData('M001', 'Alya', 'Informatika');
try {
    $presenter->showData('Alya');
    $demoInvalid = '';
} catch (InvalidArgumentException $ex) {
    $demoInvalid = $ex->getMessage();
}

require __DIR__ . '/views/home.php';
