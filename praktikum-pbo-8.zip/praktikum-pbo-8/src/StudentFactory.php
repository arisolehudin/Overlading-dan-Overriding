<?php
declare(strict_types=1);

/**
 * Satu-satunya tempat yang mengenal nama class konkret Student.
 * Repository dan tampilan hanya bergantung pada tipe abstrak Student.
 */
final class StudentFactory
{
    /** Jenis mahasiswa => label di form. */
    public const TYPE_LABELS = [
        'regular'       => 'Reguler',
        'scholarship'   => 'Beasiswa',
        'international' => 'Internasional',
    ];

    /** @param array<string,mixed> $data Input mentah dari form ($_POST). */
    public static function fromInput(array $data): Student
    {
        $id    = trim((string) ($data['id'] ?? ''));
        $name  = trim((string) ($data['name'] ?? ''));
        $major = trim((string) ($data['major'] ?? ''));
        $fee   = self::number($data['fee'] ?? null, 'Biaya dasar harus berupa angka.');

        return match ((string) ($data['type'] ?? '')) {
            'regular'       => new RegularStudent($id, $name, $major, $fee),
            'scholarship'   => new ScholarshipStudent(
                $id, $name, $major, $fee,
                self::number($data['discount'] ?? null, 'Diskon harus berupa angka.')
            ),
            'international' => new InternationalStudent($id, $name, $major, $fee),
            default         => throw new InvalidArgumentException('Jenis mahasiswa tidak dikenal.'),
        };
    }

    private static function number(mixed $value, string $message): float
    {
        $number = filter_var($value, FILTER_VALIDATE_FLOAT);
        if ($number === false) {
            throw new InvalidArgumentException($message);
        }
        return (float) $number;
    }
}
