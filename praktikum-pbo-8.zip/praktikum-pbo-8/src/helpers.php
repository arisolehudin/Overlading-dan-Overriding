<?php
declare(strict_types=1);

/** Escape output HTML. */
function e(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Format angka menjadi Rupiah, contoh: Rp5.000.000 */
function money(float $amount): string
{
    return 'Rp' . number_format($amount, 0, ',', '.');
}
