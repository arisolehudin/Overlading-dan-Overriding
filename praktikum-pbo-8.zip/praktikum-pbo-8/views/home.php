<?php
/**
 * Tampilan halaman utama.
 *
 * @var string           $error
 * @var string           $notice
 * @var ?Student         $edit
 * @var Student[]        $students
 * @var string           $search
 * @var string           $demoValid    Hasil showData() dengan 3 argumen
 * @var string           $demoInvalid  Pesan exception showData() dengan 1 argumen
 */
$currentType = $edit?->getType() ?? 'regular';
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CRUD Mahasiswa | Praktikum PBO 8</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header>
    <div class="wrap">
        <div class="small eyebrow">PBO • PERTEMUAN 8 • PHP 8+</div>
        <h1>CRUD Data Mahasiswa</h1>
        <p>Overloading melalui __call() • Overriding melalui inheritance</p>
    </div>
</header>

<main class="wrap">
    <?php if ($error): ?><div class="alert err"><?= e($error) ?></div><?php endif; ?>
    <?php if ($notice): ?><div class="alert ok"><?= e($notice) ?></div><?php endif; ?>

    <div class="grid">
        <!-- Form tambah / edit -->
        <section class="card">
            <h2><?= $edit ? 'Edit Mahasiswa' : 'Tambah Mahasiswa' ?></h2>
            <form method="post">
                <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
                <input type="hidden" name="action" value="<?= $edit ? 'update' : 'create' ?>">
                <input type="hidden" name="old_id" value="<?= e($edit?->getId() ?? '') ?>">

                <label for="id">NIM</label>
                <input id="id" name="id" required maxlength="30" value="<?= e($edit?->getId() ?? '') ?>">

                <label for="name">Nama</label>
                <input id="name" name="name" required maxlength="100" value="<?= e($edit?->getName() ?? '') ?>">

                <label for="major">Program Studi</label>
                <input id="major" name="major" required maxlength="100" value="<?= e($edit?->getMajor() ?? '') ?>">

                <label for="fee">Biaya Dasar (Rp)</label>
                <input id="fee" name="fee" type="number" min="0" step="1" required
                       value="<?= e($edit?->getBaseFee() ?? 5000000) ?>">

                <label for="type">Jenis Mahasiswa</label>
                <select id="type" name="type">
                    <?php foreach (StudentFactory::TYPE_LABELS as $value => $label): ?>
                        <option value="<?= e($value) ?>" <?= $currentType === $value ? 'selected' : '' ?>><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="discount">Diskon Beasiswa (%)</label>
                <input id="discount" name="discount" type="number" min="0" max="100" step="0.1"
                       value="<?= e($edit?->getDiscount() ?? 0) ?>">
                <p class="small">Diskon hanya digunakan untuk mahasiswa beasiswa.</p>

                <div class="actions">
                    <button type="submit"><?= $edit ? 'Simpan Perubahan' : 'Tambah Data' ?></button>
                    <?php if ($edit): ?><a class="btn secondary" href="index.php">Batal</a><?php endif; ?>
                </div>
            </form>
        </section>

        <!-- Daftar mahasiswa -->
        <section class="card">
            <h2>Daftar Mahasiswa (<?= count($students) ?>)</h2>

            <form method="get" class="search-form">
                <input name="q" placeholder="Cari NIM, nama, prodi" value="<?= e($search) ?>">
                <button>Cari</button>
                <a href="index.php" class="btn secondary">Reset</a>
            </form>

            <table>
                <thead>
                    <tr><th>Mahasiswa</th><th>Jenis</th><th>Biaya Akhir</th><th>Aksi</th></tr>
                </thead>
                <tbody>
                <?php foreach ($students as $student): ?>
                    <tr>
                        <td>
                            <strong><?= e($student->summary()) ?></strong>
                            <div class="small"><?= e($student->getMajor()) ?></div>
                        </td>
                        <td>
                            <span class="tag"><?= e($student->getType()) ?></span>
                            <?php if ($student->getDiscount() > 0): ?>
                                <div class="small">Diskon <?= e($student->getDiscount()) ?>%</div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?= e(money($student->calculateFee())) ?></strong>
                            <div class="small">Dasar <?= e(money($student->getBaseFee())) ?></div>
                        </td>
                        <td>
                            <div class="actions">
                                <a class="btn secondary" href="?edit=<?= urlencode($student->getId()) ?>">Edit</a>
                                <form method="post" onsubmit="return confirm('Hapus mahasiswa ini?')">
                                    <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf']) ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= e($student->getId()) ?>">
                                    <button class="btn danger">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (!$students): ?>
                    <tr><td colspan="4">Data tidak ditemukan.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </section>
    </div>

    <!-- Demo konsep OOP -->
    <section class="card spaced">
        <h2>Laboratorium Konsep OOP</h2>
        <p>
            <strong>Overriding:</strong> <code>calculateFee()</code> dan <code>summary()</code>
            dijalankan sesuai class object sebenarnya.
            <strong>Overloading PHP:</strong> <code>showData()</code> tidak dideklarasikan;
            panggilannya ditangani <code>StudentPresenter::__call()</code> dan hanya menerima
            tepat tiga string (id, name, major).
        </p>
        <div class="snippet">
            <div><?= e($demoValid) ?></div>
            <div class="small">showData('Alya') → <?= e($demoInvalid) ?></div>
        </div>
        <p class="small">
            Penyimpanan menggunakan PHP Session untuk tujuan praktikum. Tidak memakai database;
            data dapat hilang saat session berakhir.
        </p>
    </section>
</main>
</body>
</html>
